package models.schema;

import play.db.jpa.Model;

import java.util.*;

/**
* The basic data types such as Integers, Strings, etc.
* Auto-generated class (Schema Draft Version 0.97) - More info about this type: http://schema.org/DataType
*/
public class DataType extends Model {
}
