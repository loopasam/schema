Schema Module for Play! Framework 1.2.X

This module enables an efficient use of schema.org with any Play! application.