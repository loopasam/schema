package models.schema;

import play.db.jpa.Model;

import java.util.*;

/**
* Boolean: True or False.
* Auto-generated class (Schema Draft Version 0.97) - More info about this type: http://schema.org/Boolean
*/
public class Boolean extends Model {
}
