package models.schema;

import play.db.jpa.Model;

import java.util.*;

/**
* Data type: Number.
* Auto-generated class (Schema Draft Version 0.97) - More info about this type: http://schema.org/Number
*/
public class Number extends Model {
}
