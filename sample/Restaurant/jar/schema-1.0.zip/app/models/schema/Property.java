package models.schema;

import java.util.*;

/**
* No documentation available
* Auto-generated class (Schema Draft Version 0.97) - More info about this type: http://schema.org/Property
*/
public class Property {

	/**
	* No documentation available
	*/
	public Type range;

	/**
	* No documentation available
	*/
	public Type domain;
}
